package com.example.fivednsquick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 40, 36, 36);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF4F7FB);

        TextView title = new TextView(this);
        title.setText("5G DNS Quick Switch");
        title.setTextSize(25);
        title.setTextColor(0xFF12243A);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("\nOnePlus 13 • ARM64 • No root / No Shizuku\n\nQuick Settings mein dono tiles add kar sakte ho. Android ke security rules ke kaaran network mode aur Private DNS ke liye system settings khulengi.");
        intro.setTextSize(15);
        intro.setTextColor(0xFF34445A);
        root.addView(intro, matchWrap());

        addButton("Open 4G / 5G network settings", v -> openNetworkSettings());
        addButton("Choose DNS provider", v -> showDnsChoices());
        addButton("Wireless Debugging setup guide", v -> openWirelessDebugging());
        addButton("Add Quick Settings tiles", v -> showTileInstructions());

        setContentView(root);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = matchWrap();
        p.topMargin = 18;
        root.addView(b, p);
    }

    private void openNetworkSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void showDnsChoices() {
        final String[] names = {"Google DNS", "Cloudflare DNS", "AdGuard DNS", "Open Private DNS settings"};
        new android.app.AlertDialog.Builder(this)
            .setTitle("Choose Private DNS provider")
            .setItems(names, (dialog, which) -> {
                if (which < 3) {
                    String[] hosts = {"dns.google", "one.one.one.one", "dns.adguard-dns.com"};
                    new android.app.AlertDialog.Builder(this)
                        .setTitle(names[which])
                        .setMessage("Private DNS hostname:\n" + hosts[which] +
                                "\n\nAndroid does not let a normal app apply this system-wide automatically. Copy the hostname into Private DNS settings.")
                        .setPositiveButton("Open settings", (d, w) -> openPrivateDnsSettings())
                        .setNegativeButton("OK", null)
                        .show();
                } else {
                    openPrivateDnsSettings();
                }
            }).show();
    }

    private void openPrivateDnsSettings() {
        try {
            startActivity(new Intent("android.settings.PRIVATE_DNS_SETTINGS"));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void openWirelessDebugging() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Wireless Debugging setup")
            .setMessage("1. Open Settings > About device and tap Build number 7 times if Developer options are not enabled.\n\n2. Open Developer options > Wireless debugging and turn it on.\n\n3. Use 'Pair device with pairing code' and follow Android's system prompt.\n\nThis app does not secretly pair, obtain ADB privileges, or run privileged commands.")
            .setPositiveButton("Open Developer options", (d, w) -> {
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            })
            .setNegativeButton("Close", null)
            .show();
    }

    private void showTileInstructions() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Add Quick Settings tiles")
            .setMessage("Swipe down twice to fully expand Quick Settings, tap the pencil / Edit button, then drag '4G / 5G Switch' and 'DNS Switch' into active tiles.")
            .setPositiveButton("OK", null)
            .show();
    }
}
